"""
ReHabRep - Database helper functions (used by session_runner, seed and the API).

All data columns are encrypted automatically by the Encrypted* column types
(crypto.py). The database can only see ciphertext, so:
  - users are found by email through the email_hash blind index
  - filtering by plan status and sorting by date are done in Python, after
    the rows have been decrypted (fine for clinic-sized data)
Rows are only ever selected by their plain ids (patient_id, plan_id ...).
"""

import hashlib
import hmac
import os
from datetime import datetime, timedelta

from sqlalchemy.orm import Session as DbSession

from crypto import blind_index
from models import ExercisePlan, Patient, RepLog, Session, User

# ---------------------------------------------------------------------------
# Passwords (PBKDF2 from the standard library - no extra packages needed)
# ---------------------------------------------------------------------------
_ITERATIONS = 120_000


def hash_password(password):
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _ITERATIONS)
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password, stored):
    try:
        salt_hex, digest_hex = stored.split("$")
    except ValueError:
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), _ITERATIONS)
    return hmac.compare_digest(digest.hex(), digest_hex)


# ---------------------------------------------------------------------------
# Users / patients / plans
# ---------------------------------------------------------------------------
def get_user_by_email(db: DbSession, email):
    return db.query(User).filter(User.email_hash == blind_index(email)).first()


def create_user(db: DbSession, name, email, password, role):
    clean_email = email.lower().strip()
    user = User(
        name=name,
        email=clean_email,
        email_hash=blind_index(clean_email),
        password_hash=hash_password(password),
        role=role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_patient(db: DbSession, name, email, password, therapist_id, surgery_type=None, notes=None):
    user = create_user(db, name, email, password, "PATIENT")
    patient = Patient(
        user_id=user.id,
        therapist_id=therapist_id,
        surgery_type=surgery_type,
        notes=notes,
    )
    db.add(patient)
    db.commit()
    db.refresh(patient)
    return patient


def create_plan(db: DbSession, patient_id, exercise_type, sets, reps_per_set, min_angle, max_angle):
    """New plan becomes the active one; older plans of that exercise are deactivated."""
    if min_angle >= max_angle:
        raise ValueError("min_angle must be smaller than max_angle")

    # Deactivate older active plans of the same exercise (checked in Python - values are encrypted)
    for old in db.query(ExercisePlan).filter(ExercisePlan.patient_id == patient_id).all():
        if old.active and old.exercise_type == exercise_type:
            old.active = False

    plan = ExercisePlan(
        patient_id=patient_id,
        exercise_type=exercise_type,
        sets=sets,
        reps_per_set=reps_per_set,
        min_angle=min_angle,
        max_angle=max_angle,
        active=True,
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


def get_plan(db: DbSession, plan_id):
    return db.query(ExercisePlan).filter(ExercisePlan.id == plan_id).first()


def _newest_first(rows, attr):
    """Sort decrypted rows by a datetime attribute, newest first (missing dates last)."""
    return sorted(rows, key=lambda r: (getattr(r, attr) is not None, getattr(r, attr) or datetime.min), reverse=True)


def get_active_plans(db: DbSession, patient_id):
    plans = db.query(ExercisePlan).filter(ExercisePlan.patient_id == patient_id).all()
    return _newest_first([p for p in plans if p.active], "created_at")


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------
def save_session(db: DbSession, plan: ExercisePlan, summary, reps, source=None, pain_score=None, ended_at=None):
    """Store one finished session + its reps. `summary` comes from RepCounter.summary()."""
    ended_at = ended_at or datetime.now()
    started_at = ended_at - timedelta(seconds=summary.get("duration_s") or 0)

    session = Session(
        patient_id=plan.patient_id,
        plan_id=plan.id,
        started_at=started_at,
        ended_at=ended_at,
        min_angle=plan.min_angle,
        max_angle=plan.max_angle,
        prescribed_reps=summary["prescribed_reps"],
        reps_done=summary["reps_done"],
        good_reps=summary["good_reps"],
        under_reps=summary["under_reps"],
        over_reps=summary["over_reps"],
        accuracy_pct=summary["accuracy_pct"],
        completion_pct=summary["completion_pct"],
        adherence_pct=summary["adherence_pct"],
        max_angle_reached=summary["max_angle"],
        avg_peak_angle=summary["avg_peak_angle"],
        duration_s=summary["duration_s"],
        plan_followed=summary["plan_followed"],
        pain_score=pain_score,
        source=source,
    )
    for r in reps:
        session.reps.append(
            RepLog(
                rep_number=r["rep_number"],
                peak_angle=r["peak_angle"],
                result=r["result"],
                duration_s=r.get("duration_s"),
                time_s=r.get("time_s"),
            )
        )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


def get_sessions(db: DbSession, patient_id, limit=50):
    sessions = db.query(Session).filter(Session.patient_id == patient_id).all()
    return _newest_first(sessions, "ended_at")[:limit]