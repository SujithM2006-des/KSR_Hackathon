"""
ReHabRep - Create the tables and add demo data.

Run once:
    python src\\seed.py

Creates:
  Therapist : therapist@rehabrep.demo / therapist123
  Patient   : patient@rehabrep.demo   / patient123
  Plan      : Knee bend, 1 set x 8 reps, range 90-135 deg (matches the squat test video)
"""

from crud import create_patient, create_plan, create_user, get_active_plans, get_user_by_email
from database import DATABASE_URL, SessionLocal, init_db
from models import Patient

THERAPIST = {"name": "Dr. Priya (Physio)", "email": "therapist@rehabrep.demo", "password": "therapist123"}
PATIENT = {
    "name": "Ravi Kumar",
    "email": "patient@rehabrep.demo",
    "password": "patient123",
    "surgery_type": "Knee replacement (left)",
}


def main():
    init_db()
    db = SessionLocal()
    try:
        therapist = get_user_by_email(db, THERAPIST["email"])
        if therapist is None:
            therapist = create_user(db, THERAPIST["name"], THERAPIST["email"], THERAPIST["password"], "THERAPIST")
            print(f"Created therapist: {therapist.email}")
        else:
            print(f"Therapist exists : {therapist.email}")

        patient_user = get_user_by_email(db, PATIENT["email"])
        if patient_user is None:
            patient = create_patient(
                db,
                PATIENT["name"],
                PATIENT["email"],
                PATIENT["password"],
                therapist.id,
                surgery_type=PATIENT["surgery_type"],
            )
            print(f"Created patient  : {PATIENT['email']}")
        else:
            patient = db.query(Patient).filter(Patient.user_id == patient_user.id).first()
            print(f"Patient exists   : {PATIENT['email']}")

        plans = get_active_plans(db, patient.id)
        if plans:
            plan = plans[0]
            print("Active plan exists")
        else:
            plan = create_plan(db, patient.id, "knee", sets=1, reps_per_set=8, min_angle=90, max_angle=135)
            print("Created plan")

        print("\n----------------------------------------------")
        print(f"Database   : {DATABASE_URL}")
        print(f"Patient ID : {patient.id}  ({PATIENT['name']})")
        print(
            f"Plan ID    : {plan.id}  ({plan.exercise_type}, {plan.sets}x{plan.reps_per_set}, "
            f"{plan.min_angle:.0f}-{plan.max_angle:.0f} deg)"
        )
        print("----------------------------------------------")
        print(f"Run a session with:  python src\\session_runner.py --source videos\\squat_test.mp4 --plan-id {plan.id}")
    finally:
        db.close()


if __name__ == "__main__":
    main()