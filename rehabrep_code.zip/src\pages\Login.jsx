import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, saveLogin } from "../api.js";

const DEMO = [
  { label: "Therapist demo", email: "therapist@rehabrep.demo", password: "therapist123" },
  { label: "Patient demo", email: "patient@rehabrep.demo", password: "patient123" },
];

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function doLogin(e, creds) {
    if (e) e.preventDefault();
    const em = creds ? creds.email : email;
    const pw = creds ? creds.password : password;
    setError("");
    setBusy(true);
    try {
      const res = await api.login(em, pw);
      saveLogin(res.token, res.user);
      navigate(res.user.role === "THERAPIST" ? "/therapist" : "/patient");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-side">
        <div className="brand brand-lg">
          <span className="brand-mark">R</span>
          <span>
            ReHab<b>Rep</b>
          </span>
        </div>
        <h1>Home physio, checked rep by rep.</h1>
        <p>
          The camera counts every repetition, measures the joint angle against the range the
          physiotherapist prescribed, and coaches the patient live. The therapist sees how the
          plan was followed between visits.
        </p>
        <ul className="login-points">
          <li>Counts reps and measures joint angles from any camera</li>
          <li>Live spoken cues: "Bend a little more", "Don't go that far"</li>
          <li>Adherence report and pain check-in for the therapist</li>
        </ul>
      </div>

      <div className="login-card">
        <h2>Log in</h2>
        <form onSubmit={doLogin}>
          <label>
            Email
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          {error && <div className="alert alert-red">{error}</div>}
          <button className="btn btn-primary btn-block" disabled={busy}>
            {busy ? "Logging in..." : "Log in"}
          </button>
        </form>

        <div className="demo-box">
          <span className="muted">Quick demo login</span>
          <div className="demo-buttons">
            {DEMO.map((d) => (
              <button key={d.email} className="btn btn-outline" disabled={busy} onClick={() => doLogin(null, d)}>
                {d.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}