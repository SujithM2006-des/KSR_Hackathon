// All calls to the ReHabRep FastAPI backend go through this file.

export const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";

const TOKEN_KEY = "rehabrep_token";
const USER_KEY = "rehabrep_user";

export function getUser() {
  try {
    return JSON.parse(localStorage.getItem(USER_KEY));
  } catch {
    return null;
  }
}

function getToken() {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function saveLogin(token, user) {
  try {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  } catch {
    /* ignore */
  }
}

export function logout() {
  try {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  } catch {
    /* ignore */
  }
}

async function request(method, path, body) {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(API_URL + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error("Cannot reach the server. Is the backend running? (uvicorn api:app --app-dir src)");
  }

  if (res.status === 401 && path !== "/auth/login") {
    logout();
    window.location.href = "/login";
    throw new Error("Session expired - please log in again");
  }

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    if (data && typeof data.detail === "string") msg = data.detail;
    else if (data && Array.isArray(data.detail)) msg = data.detail.map((d) => d.msg).join(", ");
    throw new Error(msg);
  }
  return data;
}

export const api = {
  login: (email, password) => request("POST", "/auth/login", { email, password }),
  exercises: () => request("GET", "/exercises"),

  // therapist
  patients: () => request("GET", "/patients"),
  addPatient: (data) => request("POST", "/patients", data),
  patient: (id) => request("GET", `/patients/${id}`),
  assignPlan: (id, data) => request("POST", `/patients/${id}/plans`, data),
  patientSessions: (id) => request("GET", `/patients/${id}/sessions`),
  trend: (id) => request("GET", `/patients/${id}/trend`),
  session: (id) => request("GET", `/sessions/${id}`),

  // patient
  myPlans: () => request("GET", "/my/plans"),
  mySessions: () => request("GET", "/my/sessions"),
  startSession: (planId, source) =>
    request("POST", "/my/sessions/start", { plan_id: planId, source: source || null }),
  setPain: (sessionId, pain) => request("PATCH", `/sessions/${sessionId}/pain`, { pain_score: pain }),
};

// ---------- small display helpers ----------
export function fmtDate(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

export function fmtNum(v, digits = 0) {
  return v === null || v === undefined ? "-" : Number(v).toFixed(digits);
}