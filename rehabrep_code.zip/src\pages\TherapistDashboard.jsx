import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, fmtDate } from "../api.js";
import { AdherenceBadge, FollowedBadge } from "../components/Badge.jsx";

const EMPTY = { name: "", email: "", password: "", surgery_type: "", notes: "" };

export default function TherapistDashboard() {
  const [patients, setPatients] = useState(null);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    try {
      setPatients(await api.patients());
      setError("");
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function addPatient(e) {
    e.preventDefault();
    setFormError("");
    setSaving(true);
    try {
      await api.addPatient({
        ...form,
        surgery_type: form.surgery_type || null,
        notes: form.notes || null,
      });
      setForm(EMPTY);
      setShowForm(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  const list = patients || [];
  const alerts = list.filter((p) => p.pain_alert || p.badge.color === "red");
  const onTrack = list.filter((p) => p.badge.color === "green").length;

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>My patients</h1>
          <p className="muted">Adherence is the average of each patient's last 5 sessions.</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm((s) => !s)}>
          {showForm ? "Cancel" : "+ Add patient"}
        </button>
      </div>

      {error && <div className="alert alert-red">{error}</div>}

      {showForm && (
        <form className="card form-grid" onSubmit={addPatient}>
          <h3 className="span-2">New patient</h3>
          <label>
            Full name
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </label>
          <label>
            Email (patient's login)
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
          </label>
          <label>
            Temporary password (min 6)
            <input
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              minLength={6}
              required
            />
          </label>
          <label>
            Surgery / condition
            <input
              value={form.surgery_type}
              placeholder="e.g. Knee replacement (right)"
              onChange={(e) => setForm({ ...form, surgery_type: e.target.value })}
            />
          </label>
          <label className="span-2">
            Notes
            <input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </label>
          {formError && <div className="alert alert-red span-2">{formError}</div>}
          <div className="span-2">
            <button className="btn btn-primary" disabled={saving}>
              {saving ? "Saving..." : "Save patient"}
            </button>
          </div>
        </form>
      )}

      <div className="stats">
        <div className="stat">
          <span className="stat-num">{list.length}</span>
          <span className="stat-label">Patients</span>
        </div>
        <div className="stat">
          <span className="stat-num ok">{onTrack}</span>
          <span className="stat-label">On track</span>
        </div>
        <div className="stat">
          <span className={`stat-num ${alerts.length ? "bad" : ""}`}>{alerts.length}</span>
          <span className="stat-label">Need a call</span>
        </div>
      </div>

      {alerts.length > 0 && (
        <div className="alert alert-red">
          <b>Check today:</b>{" "}
          {alerts.map((p, i) => (
            <span key={p.id}>
              {i > 0 && ", "}
              <Link to={`/therapist/patients/${p.id}`}>{p.name}</Link>
              {p.pain_alert ? " (high pain reported)" : " (not following plan)"}
            </span>
          ))}
        </div>
      )}

      <div className="card table-card">
        {patients === null && !error ? (
          <p className="muted pad">Loading...</p>
        ) : list.length === 0 ? (
          <p className="muted pad">No patients yet. Add your first patient above.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Patient</th>
                <th>Current plan</th>
                <th>Last session</th>
                <th>Last result</th>
                <th>Adherence</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => {
                const plan = p.active_plans[0];
                const last = p.last_session;
                return (
                  <tr key={p.id}>
                    <td>
                      <div className="strong">
                        {p.name} {p.pain_alert && <span className="badge badge-red">Pain</span>}
                      </div>
                      <div className="muted small">{p.surgery_type || "-"}</div>
                    </td>
                    <td>
                      {plan ? (
                        <>
                          <div>{plan.exercise_name}</div>
                          <div className="muted small">
                            {plan.sets}×{plan.reps_per_set} · {plan.min_angle}°–{plan.max_angle}°
                            {p.active_plans.length > 1 ? ` · +${p.active_plans.length - 1} more` : ""}
                          </div>
                        </>
                      ) : (
                        <span className="muted">No plan yet</span>
                      )}
                    </td>
                    <td>{fmtDate(p.last_session_at)}</td>
                    <td>
                      {last ? (
                        <>
                          {last.good_reps}/{last.prescribed_reps} correct <FollowedBadge value={last.plan_followed} />
                        </>
                      ) : (
                        <span className="muted">-</span>
                      )}
                    </td>
                    <td>
                      <AdherenceBadge badge={p.badge} />
                    </td>
                    <td className="right">
                      <Link className="btn btn-outline btn-sm" to={`/therapist/patients/${p.id}`}>
                        Open
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}