import { Link, useNavigate } from "react-router-dom";
import { logout } from "../api.js";

export default function Layout({ user, children }) {
  const navigate = useNavigate();
  const home = user.role === "THERAPIST" ? "/therapist" : "/patient";

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <div className="app">
      <header className="topbar">
        <Link to={home} className="brand">
          <span className="brand-mark">R</span>
          <span>
            ReHab<b>Rep</b>
          </span>
        </Link>
        <div className="topbar-right">
          <span className="who">
            {user.name}
            <span className="role-chip">{user.role === "THERAPIST" ? "Therapist" : "Patient"}</span>
          </span>
          <button className="btn btn-ghost" onClick={handleLogout}>
            Log out
          </button>
        </div>
      </header>
      <main className="content">{children}</main>
      <footer className="disclaimer">
        Exercise aid only. Not a diagnosis. Follow your physiotherapist's advice.
      </footer>
    </div>
  );
}