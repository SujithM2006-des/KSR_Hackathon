import { Navigate, Route, Routes } from "react-router-dom";
import { getUser } from "./api.js";
import Layout from "./components/Layout.jsx";
import Login from "./pages/Login.jsx";
import TherapistDashboard from "./pages/TherapistDashboard.jsx";
import PatientDetail from "./pages/PatientDetail.jsx";
import SessionReport from "./pages/SessionReport.jsx";
import PatientHome from "./pages/PatientHome.jsx";

function RequireRole({ role, children }) {
  const user = getUser();
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) {
    return <Navigate to={user.role === "THERAPIST" ? "/therapist" : "/patient"} replace />;
  }
  return <Layout user={user}>{children}</Layout>;
}

function HomeRedirect() {
  const user = getUser();
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={user.role === "THERAPIST" ? "/therapist" : "/patient"} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/therapist"
        element={
          <RequireRole role="THERAPIST">
            <TherapistDashboard />
          </RequireRole>
        }
      />
      <Route
        path="/therapist/patients/:id"
        element={
          <RequireRole role="THERAPIST">
            <PatientDetail />
          </RequireRole>
        }
      />
      <Route
        path="/sessions/:id"
        element={
          <RequireRole>
            <SessionReport />
          </RequireRole>
        }
      />
      <Route
        path="/patient"
        element={
          <RequireRole role="PATIENT">
            <PatientHome />
          </RequireRole>
        }
      />
      <Route path="*" element={<HomeRedirect />} />
    </Routes>
  );
}