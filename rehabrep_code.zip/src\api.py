"""
ReHabRep - Backend API (FastAPI).

Run from D:\\PROJECT\\KSR (venv active):
    uvicorn api:app --reload --app-dir src

Interactive docs: http://127.0.0.1:8000/docs

THERAPIST
  POST  /auth/login                      -> token
  GET   /patients                        patient list + adherence badge + pain flag
  POST  /patients                        add a patient
  GET   /patients/{id}                   profile + active plans
  POST  /patients/{id}/plans             assign plan (exercise, sets, reps, min/max angle)
  GET   /patients/{id}/sessions          session history (adherence reports)
  GET   /patients/{id}/trend             data for progress charts
  GET   /sessions/{id}                   one report with every rep
  GET   /exercises                       exercise library (names, camera view, default ranges)

PATIENT
  GET   /my/plans                        today's active plan(s)
  POST  /my/sessions/start               opens the exercise window (session_runner)
  GET   /my/sessions                     my past sessions
  PATCH /sessions/{id}/pain              pain check-in (0-10) after a session
"""

import base64
import hashlib
import hmac
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as DbSession

from crud import create_patient, create_plan, get_active_plans, get_sessions, get_user_by_email, verify_password
from database import PROJECT_ROOT, get_db, init_db
from exercises import EXERCISES, exercise_list, resolve_exercise
from models import Patient, Session, User

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
SECRET = os.getenv("REHABREP_SECRET", "rehabrep-dev-secret-change-me")
TOKEN_HOURS = 12
DEFAULT_DEMO_VIDEO = os.path.join("videos", "squat_test.mp4")
HIGH_PAIN = 7
RECENT_SESSIONS = 5  # sessions used for the adherence badge

app = FastAPI(title="ReHabRep API", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()


# ---------------------------------------------------------------------------
# Tokens (HMAC-signed, standard library only)
# ---------------------------------------------------------------------------
def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def make_token(user: User) -> str:
    payload = {"uid": user.id, "role": user.role, "exp": int(time.time()) + TOKEN_HOURS * 3600}
    body = _b64(json.dumps(payload).encode())
    sig = _b64(hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"


def read_token(token: str) -> Optional[dict]:
    try:
        body, sig = token.split(".")
        expected = _b64(hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(_unb64(body))
        if payload["exp"] < time.time():
            return None
        return payload
    except Exception:
        return None


bearer = HTTPBearer(auto_error=False)


def current_user(
    creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
    db: DbSession = Depends(get_db),
) -> User:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not logged in")
    payload = read_token(creds.credentials)
    if payload is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
    user = db.query(User).filter(User.id == payload["uid"]).first()
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found")
    return user


def require_therapist(user: User = Depends(current_user)) -> User:
    if user.role != "THERAPIST":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Therapists only")
    return user


def require_patient(user: User = Depends(current_user)) -> User:
    if user.role != "PATIENT" or user.patient_profile is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Patients only")
    return user


def therapist_patient(db: DbSession, therapist: User, patient_id: int) -> Patient:
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if patient is None or patient.therapist_id != therapist.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Patient not found")
    return patient


# ---------------------------------------------------------------------------
# Request bodies
# ---------------------------------------------------------------------------
class LoginIn(BaseModel):
    email: str
    password: str


class PatientIn(BaseModel):
    name: str = Field(min_length=2)
    email: str
    password: str = Field(min_length=6)
    surgery_type: Optional[str] = None
    notes: Optional[str] = None


class PlanIn(BaseModel):
    exercise_type: str = "mini_squat"
    sets: int = Field(3, ge=1, le=10)
    reps_per_set: int = Field(10, ge=1, le=50)
    min_angle: float = Field(ge=0, le=180)
    max_angle: float = Field(ge=0, le=180)


class StartIn(BaseModel):
    plan_id: int
    source: Optional[str] = None  # video path or webcam index; default = demo video


class PainIn(BaseModel):
    pain_score: int = Field(ge=0, le=10)


# ---------------------------------------------------------------------------
# Serialisers
# ---------------------------------------------------------------------------
def exercise_info(key) -> dict:
    real = resolve_exercise(key)
    ex = EXERCISES.get(real, {})
    return {
        "exercise_type": real or key,
        "exercise_name": ex.get("name", key),
        "joint": ex.get("joint"),
        "direction": ex.get("direction", "up"),
        "view": ex.get("view"),
        "instructions": ex.get("instructions"),
    }


def plan_out(plan) -> dict:
    return {
        "id": plan.id,
        **exercise_info(plan.exercise_type),
        "sets": plan.sets,
        "reps_per_set": plan.reps_per_set,
        "prescribed_reps": plan.prescribed_reps,
        "min_angle": plan.min_angle,
        "max_angle": plan.max_angle,
        "active": plan.active,
        "created_at": plan.created_at.isoformat() if plan.created_at else None,
    }


def session_out(s: Session, with_reps=False) -> dict:
    data = {
        "id": s.id,
        "patient_id": s.patient_id,
        "plan_id": s.plan_id,
        **exercise_info(s.plan.exercise_type if s.plan else "mini_squat"),
        "started_at": s.started_at.isoformat() if s.started_at else None,
        "ended_at": s.ended_at.isoformat() if s.ended_at else None,
        "min_angle": s.min_angle,
        "max_angle": s.max_angle,
        "prescribed_reps": s.prescribed_reps,
        "reps_done": s.reps_done,
        "good_reps": s.good_reps,
        "under_reps": s.under_reps,
        "over_reps": s.over_reps,
        "accuracy_pct": s.accuracy_pct,
        "completion_pct": s.completion_pct,
        "adherence_pct": s.adherence_pct,
        "max_angle_reached": s.max_angle_reached,  # BEST angle (lowest for "down" exercises)
        "avg_peak_angle": s.avg_peak_angle,
        "duration_s": s.duration_s,
        "plan_followed": s.plan_followed,
        "pain_score": s.pain_score,
        "high_pain": s.pain_score is not None and s.pain_score >= HIGH_PAIN,
    }
    if with_reps:
        data["reps"] = [
            {
                "rep_number": r.rep_number,
                "peak_angle": r.peak_angle,
                "result": r.result,
                "duration_s": r.duration_s,
                "time_s": r.time_s,
            }
            for r in s.reps
        ]
    return data


def adherence_badge(sessions: List[Session]) -> dict:
    """Badge from the average adherence of the most recent sessions."""
    recent = sessions[:RECENT_SESSIONS]
    if not recent:
        return {"color": "grey", "label": "No sessions yet", "avg_adherence_pct": None}
    avg = round(sum(s.adherence_pct for s in recent) / len(recent), 1)
    if avg >= 80:
        color, label = "green", "On track"
    elif avg >= 50:
        color, label = "amber", "Needs attention"
    else:
        color, label = "red", "Not following plan"
    return {"color": color, "label": label, "avg_adherence_pct": avg}


def patient_summary(db: DbSession, p: Patient) -> dict:
    sessions = get_sessions(db, p.id)
    recent = sessions[:RECENT_SESSIONS]
    last = sessions[0] if sessions else None
    return {
        "id": p.id,
        "name": p.user.name,
        "email": p.user.email,
        "surgery_type": p.surgery_type,
        "notes": p.notes,
        "active_plans": [plan_out(pl) for pl in get_active_plans(db, p.id)],
        "sessions_count": len(sessions),
        "last_session_at": last.ended_at.isoformat() if last else None,
        "last_session": session_out(last) if last else None,
        "badge": adherence_badge(sessions),
        "pain_alert": any(s.pain_score is not None and s.pain_score >= HIGH_PAIN for s in recent),
    }


# ---------------------------------------------------------------------------
# Routes - general
# ---------------------------------------------------------------------------
@app.get("/")
def root():
    return {"app": "ReHabRep API", "docs": "/docs"}


@app.post("/auth/login")
def login(body: LoginIn, db: DbSession = Depends(get_db)):
    user = get_user_by_email(db, body.email)
    if user is None or not verify_password(body.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Wrong email or password")
    return {
        "token": make_token(user),
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "patient_id": user.patient_profile.id if user.patient_profile else None,
        },
    }


@app.get("/me")
def me(user: User = Depends(current_user)):
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "patient_id": user.patient_profile.id if user.patient_profile else None,
    }


@app.get("/exercises")
def exercises():
    return exercise_list()


# ---------------------------------------------------------------------------
# Routes - therapist
# ---------------------------------------------------------------------------
@app.get("/patients")
def list_patients(therapist: User = Depends(require_therapist), db: DbSession = Depends(get_db)):
    patients = db.query(Patient).filter(Patient.therapist_id == therapist.id).order_by(Patient.id).all()
    return [patient_summary(db, p) for p in patients]


@app.post("/patients", status_code=201)
def add_patient(body: PatientIn, therapist: User = Depends(require_therapist), db: DbSession = Depends(get_db)):
    if get_user_by_email(db, body.email):
        raise HTTPException(status.HTTP_409_CONFLICT, "Email already registered")
    p = create_patient(
        db, body.name, body.email, body.password, therapist.id,
        surgery_type=body.surgery_type, notes=body.notes,
    )
    return patient_summary(db, p)


@app.get("/patients/{patient_id}")
def get_patient(patient_id: int, therapist: User = Depends(require_therapist), db: DbSession = Depends(get_db)):
    return patient_summary(db, therapist_patient(db, therapist, patient_id))


@app.post("/patients/{patient_id}/plans", status_code=201)
def assign_plan(
    patient_id: int,
    body: PlanIn,
    therapist: User = Depends(require_therapist),
    db: DbSession = Depends(get_db),
):
    therapist_patient(db, therapist, patient_id)
    exercise_key = resolve_exercise(body.exercise_type)
    if exercise_key is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Unknown exercise '{body.exercise_type}'")
    if body.min_angle >= body.max_angle:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Minimum angle must be less than maximum angle")
    plan = create_plan(
        db, patient_id, exercise_key, body.sets, body.reps_per_set, body.min_angle, body.max_angle
    )
    return plan_out(plan)


@app.get("/patients/{patient_id}/sessions")
def patient_sessions(patient_id: int, therapist: User = Depends(require_therapist), db: DbSession = Depends(get_db)):
    therapist_patient(db, therapist, patient_id)
    return [session_out(s) for s in get_sessions(db, patient_id)]


@app.get("/patients/{patient_id}/trend")
def patient_trend(patient_id: int, therapist: User = Depends(require_therapist), db: DbSession = Depends(get_db)):
    therapist_patient(db, therapist, patient_id)
    sessions = list(reversed(get_sessions(db, patient_id)))  # oldest first for charts
    return [
        {
            "session_id": s.id,
            **exercise_info(s.plan.exercise_type if s.plan else "mini_squat"),
            "date": s.ended_at.strftime("%d %b %H:%M") if s.ended_at else "",
            "max_angle": s.max_angle_reached,
            "avg_peak_angle": s.avg_peak_angle,
            "accuracy_pct": s.accuracy_pct,
            "adherence_pct": s.adherence_pct,
            "pain_score": s.pain_score,
            "target_min": s.min_angle,
            "target_max": s.max_angle,
        }
        for s in sessions
    ]


@app.get("/sessions/{session_id}")
def session_detail(session_id: int, user: User = Depends(current_user), db: DbSession = Depends(get_db)):
    s = db.query(Session).filter(Session.id == session_id).first()
    if s is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")
    allowed = (user.role == "THERAPIST" and s.patient.therapist_id == user.id) or (
        user.role == "PATIENT" and user.patient_profile and user.patient_profile.id == s.patient_id
    )
    if not allowed:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")
    return session_out(s, with_reps=True)


# ---------------------------------------------------------------------------
# Routes - patient
# ---------------------------------------------------------------------------
@app.get("/my/plans")
def my_plans(user: User = Depends(require_patient), db: DbSession = Depends(get_db)):
    return [plan_out(p) for p in get_active_plans(db, user.patient_profile.id)]


@app.get("/my/sessions")
def my_sessions(user: User = Depends(require_patient), db: DbSession = Depends(get_db)):
    return [session_out(s) for s in get_sessions(db, user.patient_profile.id)]


@app.post("/my/sessions/start")
def start_session(body: StartIn, user: User = Depends(require_patient), db: DbSession = Depends(get_db)):
    """Opens the ReHabRep exercise window on this computer for the chosen plan."""
    plans = {p.id for p in get_active_plans(db, user.patient_profile.id)}
    if body.plan_id not in plans:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Plan not found")

    source = body.source or DEFAULT_DEMO_VIDEO
    if not source.isdigit() and not os.path.isfile(os.path.join(PROJECT_ROOT, source)) and not os.path.isfile(source):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Video not found: {source}")

    cmd = [
        sys.executable,
        os.path.join(SRC_DIR, "session_runner.py"),
        "--plan-id", str(body.plan_id),
        "--source", source,
    ]
    # stdin=DEVNULL: no terminal pain question - the web page asks instead
    proc = subprocess.Popen(cmd, cwd=PROJECT_ROOT, stdin=subprocess.DEVNULL)
    return {"started": True, "pid": proc.pid, "source": source, "started_at": datetime.now().isoformat()}


@app.patch("/sessions/{session_id}/pain")
def set_pain(session_id: int, body: PainIn, user: User = Depends(require_patient), db: DbSession = Depends(get_db)):
    s = db.query(Session).filter(Session.id == session_id).first()
    if s is None or s.patient_id != user.patient_profile.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")
    s.pain_score = body.pain_score
    db.commit()
    db.refresh(s)
    return session_out(s)