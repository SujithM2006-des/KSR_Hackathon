// Small coloured labels used across the app.

export function AdherenceBadge({ badge }) {
  if (!badge) return null;
  const pct = badge.avg_adherence_pct;
  return (
    <span className={`badge badge-${badge.color}`}>
      <span className="dot" />
      {badge.label}
      {pct !== null && pct !== undefined ? ` · ${pct}%` : ""}
    </span>
  );
}

export function ResultBadge({ result }) {
  const cls = { GOOD: "green", UNDER: "amber", OVER: "red" }[result] || "grey";
  return <span className={`badge badge-${cls}`}>{result}</span>;
}

export function FollowedBadge({ value }) {
  const cls = { YES: "green", PARTLY: "amber", NO: "red" }[value] || "grey";
  return <span className={`badge badge-${cls}`}>{value}</span>;
}

export function PainBadge({ score }) {
  if (score === null || score === undefined) return <span className="muted">-</span>;
  const cls = score >= 7 ? "red" : score >= 4 ? "amber" : "green";
  return (
    <span className={`badge badge-${cls}`}>
      {score}/10{score >= 7 ? " · HIGH" : ""}
    </span>
  );
}