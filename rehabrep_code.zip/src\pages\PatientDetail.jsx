import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceArea,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api, fmtDate, fmtNum } from "../api.js";
import { AdherenceBadge, FollowedBadge, PainBadge } from "../components/Badge.jsx";

export default function PatientDetail() {
  const { id } = useParams();
  const [patient, setPatient] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [trend, setTrend] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [error, setError] = useState("");

  const [plan, setPlan] = useState({ exercise_type: "", sets: 3, reps_per_set: 10, min_angle: "", max_angle: "" });
  const [planMsg, setPlanMsg] = useState(null);
  const [saving, setSaving] = useState(false);
  const [chartExercise, setChartExercise] = useState("");

  async function load() {
    try {
      const [p, s, t] = await Promise.all([api.patient(id), api.patientSessions(id), api.trend(id)]);
      setPatient(p);
      setSessions(s);
      setTrend(t);
      setError("");
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
    api
      .exercises()
      .then((list) => {
        setExercises(list);
        if (list.length) {
          const ex = list[0];
          setPlan((p) => ({ ...p, exercise_type: ex.key, min_angle: ex.default_min, max_angle: ex.default_max }));
        }
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const selectedEx = exercises.find((e) => e.key === plan.exercise_type);

  function chooseExercise(key) {
    const ex = exercises.find((e) => e.key === key);
    setPlan({ ...plan, exercise_type: key, min_angle: ex ? ex.default_min : "", max_angle: ex ? ex.default_max : "" });
  }

  async function assignPlan(e) {
    e.preventDefault();
    setPlanMsg(null);
    setSaving(true);
    try {
      await api.assignPlan(id, {
        exercise_type: plan.exercise_type,
        sets: Number(plan.sets),
        reps_per_set: Number(plan.reps_per_set),
        min_angle: Number(plan.min_angle),
        max_angle: Number(plan.max_angle),
      });
      setPlanMsg({ ok: true, text: "Plan assigned. The patient will see it on their home page." });
      load();
    } catch (err) {
      setPlanMsg({ ok: false, text: err.message });
    } finally {
      setSaving(false);
    }
  }

  // ---- progress chart: one exercise at a time ----
  const trendExercises = useMemo(() => {
    const seen = new Map();
    trend.forEach((t) => seen.set(t.exercise_type, t.exercise_name));
    return [...seen.entries()];
  }, [trend]);

  const activeChartEx = chartExercise || (trendExercises.length ? trendExercises[trendExercises.length - 1][0] : "");
  const chartData = trend.filter((t) => t.exercise_type === activeChartEx);
  const lastTarget = chartData.length ? chartData[chartData.length - 1] : null;

  if (error) return <div className="alert alert-red">{error}</div>;
  if (!patient) return <p className="muted">Loading...</p>;

  return (
    <div>
      <Link to="/therapist" className="back">
        ← All patients
      </Link>

      <div className="page-head">
        <div>
          <h1>
            {patient.name} {patient.pain_alert && <span className="badge badge-red">High pain reported</span>}
          </h1>
          <p className="muted">
            {patient.surgery_type || "No condition recorded"} · {patient.email} · {patient.sessions_count} sessions
          </p>
        </div>
        <AdherenceBadge badge={patient.badge} />
      </div>

      <div className="grid-2">
        {/* ---------- Active plans ---------- */}
        <div className="card">
          <h3>Current plan</h3>
          {patient.active_plans.length === 0 ? (
            <p className="muted">No plan yet - assign one on the right.</p>
          ) : (
            patient.active_plans.map((p) => (
              <div key={p.id} className="plan-row">
                <div>
                  <div className="strong">{p.exercise_name}</div>
                  <div className="muted small">
                    {p.sets} {p.sets === 1 ? "set" : "sets"} × {p.reps_per_set} reps · camera: {p.view} view
                  </div>
                </div>
                <div className="range-pill">
                  {p.min_angle}° – {p.max_angle}°
                </div>
              </div>
            ))
          )}
        </div>

        {/* ---------- Assign plan ---------- */}
        <form className="card form-grid" onSubmit={assignPlan}>
          <h3 className="span-2">Assign / update plan</h3>
          <label className="span-2">
            Exercise
            <select value={plan.exercise_type} onChange={(e) => chooseExercise(e.target.value)}>
              {exercises.map((ex) => (
                <option key={ex.key} value={ex.key}>
                  {ex.joint} · {ex.name}
                </option>
              ))}
            </select>
          </label>
          {selectedEx && (
            <p className="muted small span-2">
              Measures {selectedEx.measure.toLowerCase()}, {selectedEx.view} camera view.{" "}
              {selectedEx.direction === "down"
                ? "Lower angle = straighter; the patient must reach at most the max angle."
                : "The patient must reach at least the min angle and not go past the max."}
            </p>
          )}
          <label>
            Min angle (°)
            <input
              type="number"
              min="0"
              max="180"
              value={plan.min_angle}
              onChange={(e) => setPlan({ ...plan, min_angle: e.target.value })}
              required
            />
          </label>
          <label>
            Max angle (°)
            <input
              type="number"
              min="0"
              max="180"
              value={plan.max_angle}
              onChange={(e) => setPlan({ ...plan, max_angle: e.target.value })}
              required
            />
          </label>
          <label>
            Sets
            <input
              type="number"
              min="1"
              max="10"
              value={plan.sets}
              onChange={(e) => setPlan({ ...plan, sets: e.target.value })}
              required
            />
          </label>
          <label>
            Reps per set
            <input
              type="number"
              min="1"
              max="50"
              value={plan.reps_per_set}
              onChange={(e) => setPlan({ ...plan, reps_per_set: e.target.value })}
              required
            />
          </label>
          {planMsg && <div className={`alert span-2 ${planMsg.ok ? "alert-green" : "alert-red"}`}>{planMsg.text}</div>}
          <div className="span-2">
            <button className="btn btn-primary" disabled={saving || !plan.exercise_type}>
              {saving ? "Saving..." : "Assign plan"}
            </button>
          </div>
        </form>
      </div>

      {/* ---------- Progress chart ---------- */}
      <div className="card">
        <div className="card-head">
          <h3>Progress - best angle per session</h3>
          {trendExercises.length > 1 && (
            <select value={activeChartEx} onChange={(e) => setChartExercise(e.target.value)}>
              {trendExercises.map(([key, name]) => (
                <option key={key} value={key}>
                  {name}
                </option>
              ))}
            </select>
          )}
        </div>
        {chartData.length === 0 ? (
          <p className="muted">No sessions yet.</p>
        ) : (
          <>
            <p className="muted small">
              {chartData[0].exercise_name}. Green band = current prescribed range ({lastTarget.target_min}° –{" "}
              {lastTarget.target_max}°).
            </p>
            <div className="chart">
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <CartesianGrid stroke="#e8edf0" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 12, fill: "#5b6b75" }} />
                  <YAxis domain={[0, 180]} tick={{ fontSize: 12, fill: "#5b6b75" }} unit="°" />
                  <ReferenceArea
                    y1={lastTarget.target_min}
                    y2={lastTarget.target_max}
                    fill="#16a34a"
                    fillOpacity={0.1}
                    stroke="#16a34a"
                    strokeOpacity={0.3}
                  />
                  <Tooltip
                    formatter={(v, name) => [`${fmtNum(v, 1)}°`, name]}
                    contentStyle={{ borderRadius: 8, fontSize: 13 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="max_angle"
                    name="Best angle"
                    stroke="#0f766e"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="avg_peak_angle"
                    name="Average per rep"
                    stroke="#94a3b8"
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
      </div>

      {/* ---------- Session history ---------- */}
      <div className="card table-card">
        <h3 className="pad-x">Session history (adherence reports)</h3>
        {sessions.length === 0 ? (
          <p className="muted pad">No sessions yet.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Exercise</th>
                <th>Reps done</th>
                <th>Correct</th>
                <th>Under / Over</th>
                <th>Best angle</th>
                <th>Pain</th>
                <th>Plan followed</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sessions.map((s) => (
                <tr key={s.id} className={s.high_pain ? "row-alert" : ""}>
                  <td>{fmtDate(s.ended_at)}</td>
                  <td>
                    <div>{s.exercise_name}</div>
                    <div className="muted small">
                      {s.min_angle}° – {s.max_angle}°
                    </div>
                  </td>
                  <td>
                    {s.reps_done}/{s.prescribed_reps}
                  </td>
                  <td>
                    {s.good_reps} <span className="muted small">({fmtNum(s.accuracy_pct)}%)</span>
                  </td>
                  <td>
                    {s.under_reps} / {s.over_reps}
                  </td>
                  <td>{fmtNum(s.max_angle_reached, 1)}°</td>
                  <td>
                    <PainBadge score={s.pain_score} />
                  </td>
                  <td>
                    <FollowedBadge value={s.plan_followed} />
                  </td>
                  <td className="right">
                    <Link className="btn btn-outline btn-sm" to={`/sessions/${s.id}`}>
                      Report
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}