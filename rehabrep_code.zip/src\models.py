"""
ReHabRep - Database tables.

users           therapists and patients (role = THERAPIST | PATIENT)
patients        patient profile, linked to a user and to their therapist
exercise_plans  what the therapist prescribes (exercise, sets, reps, min/max angle)
sessions        one row per exercise session (the adherence report)
rep_logs        one row per rep inside a session

Encryption (see crypto.py):
  EVERY data column is stored ENCRYPTED (names, emails, roles, surgery type,
  notes, plans, angles, rep counts, results, pain scores, dates).
  Stored plain only:
    - id / *_id columns  -> row numbers that link the tables together
    - email_hash         -> HMAC fingerprint used to find a user at login
    - password_hash      -> salted PBKDF2 hash (one-way, cannot be decrypted)
  Because values are encrypted, the database cannot sort or filter them;
  crud.py does that in Python.
"""

from datetime import datetime

from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from crypto import EncryptedBool, EncryptedDateTime, EncryptedFloat, EncryptedInt, EncryptedText
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(EncryptedText, nullable=False)  # encrypted
    email = Column(EncryptedText, nullable=False)  # encrypted
    email_hash = Column(String(64), unique=True, nullable=False, index=True)  # blind index for login
    password_hash = Column(String(255), nullable=False)
    role = Column(EncryptedText, nullable=False)  # encrypted: THERAPIST | PATIENT
    created_at = Column(EncryptedDateTime, default=datetime.utcnow)  # encrypted

    patient_profile = relationship(
        "Patient", back_populates="user", uselist=False, foreign_keys="Patient.user_id"
    )
    patients = relationship(
        "Patient", back_populates="therapist", foreign_keys="Patient.therapist_id"
    )


class Patient(Base):
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    therapist_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    surgery_type = Column(EncryptedText, nullable=True)  # encrypted, e.g. "Knee replacement (left)"
    notes = Column(EncryptedText, nullable=True)  # encrypted
    created_at = Column(EncryptedDateTime, default=datetime.utcnow)  # encrypted

    user = relationship("User", back_populates="patient_profile", foreign_keys=[user_id])
    therapist = relationship("User", back_populates="patients", foreign_keys=[therapist_id])
    plans = relationship("ExercisePlan", back_populates="patient", cascade="all, delete-orphan")
    sessions = relationship("Session", back_populates="patient", cascade="all, delete-orphan")


class ExercisePlan(Base):
    __tablename__ = "exercise_plans"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    # all encrypted
    exercise_type = Column(EncryptedText, nullable=False, default="mini_squat")  # key in EXERCISES
    sets = Column(EncryptedInt, nullable=False, default=3)
    reps_per_set = Column(EncryptedInt, nullable=False, default=10)
    min_angle = Column(EncryptedFloat, nullable=False)
    max_angle = Column(EncryptedFloat, nullable=False)
    active = Column(EncryptedBool, nullable=False, default=True)
    created_at = Column(EncryptedDateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="plans")
    sessions = relationship("Session", back_populates="plan")

    @property
    def prescribed_reps(self):
        return self.sets * self.reps_per_set


class Session(Base):
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    plan_id = Column(Integer, ForeignKey("exercise_plans.id"), nullable=False)
    # all encrypted
    started_at = Column(EncryptedDateTime, default=datetime.utcnow)
    ended_at = Column(EncryptedDateTime, default=datetime.utcnow)

    # Copy of the plan at the time of the session (plans can change later)
    min_angle = Column(EncryptedFloat, nullable=False)
    max_angle = Column(EncryptedFloat, nullable=False)
    prescribed_reps = Column(EncryptedInt, nullable=False)

    reps_done = Column(EncryptedInt, nullable=False, default=0)
    good_reps = Column(EncryptedInt, nullable=False, default=0)
    under_reps = Column(EncryptedInt, nullable=False, default=0)
    over_reps = Column(EncryptedInt, nullable=False, default=0)
    accuracy_pct = Column(EncryptedFloat, nullable=False, default=0.0)
    completion_pct = Column(EncryptedFloat, nullable=False, default=0.0)
    adherence_pct = Column(EncryptedFloat, nullable=False, default=0.0)
    max_angle_reached = Column(EncryptedFloat, nullable=True)
    avg_peak_angle = Column(EncryptedFloat, nullable=True)
    duration_s = Column(EncryptedFloat, nullable=True)
    plan_followed = Column(EncryptedText, nullable=False, default="NO")  # YES | PARTLY | NO
    pain_score = Column(EncryptedInt, nullable=True)  # 0-10, patient check-in
    source = Column(EncryptedText, nullable=True)

    patient = relationship("Patient", back_populates="sessions")
    plan = relationship("ExercisePlan", back_populates="sessions")
    # Ordered by id (= order the reps were saved); rep_number is encrypted so the DB can't sort it
    reps = relationship("RepLog", back_populates="session", cascade="all, delete-orphan", order_by="RepLog.id")


class RepLog(Base):
    __tablename__ = "rep_logs"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    # all encrypted
    rep_number = Column(EncryptedInt, nullable=False)
    peak_angle = Column(EncryptedFloat, nullable=False)
    result = Column(EncryptedText, nullable=False)  # GOOD | UNDER | OVER
    duration_s = Column(EncryptedFloat, nullable=True)
    time_s = Column(EncryptedFloat, nullable=True)

    session = relationship("Session", back_populates="reps")